from CameraStatus import *
a = CameraStatus().Get_Camera_Status()
print type(CameraStatus().processDict.keys()[0])
print type(CameraStatus().EXE_Size)