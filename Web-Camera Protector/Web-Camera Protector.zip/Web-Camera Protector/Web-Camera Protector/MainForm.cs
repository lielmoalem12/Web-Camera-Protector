﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;

namespace Web_Camera_Protector
{
    public partial class MainForm : Form
    {
        private NotifyIcon  trayIcon;
        private ContextMenu trayMenu;
        Socket s = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        public MainForm()
        {

            s.Connect("127.0.0.1", 5555);
            InitializeComponent();
            // Create a simple tray menu with only one item.
            trayMenu = new ContextMenu();
            trayMenu.MenuItems.Add("Open", OnOpen);
            trayMenu.MenuItems.Add("Exit", OnExit);
            // Create a tray icon. In this example we use a
            // standard system icon for simplicity, but youפ
            // can of course use your own custom icon too.
            trayIcon      = new NotifyIcon();
            trayIcon.Text = "MyTrayApp";
            trayIcon.Icon = Properties.Resources.old_cam_ra;
            trayIcon.MouseDoubleClick +=new MouseEventHandler(trayIcon_MouseDoubleClick);
 
            // Add menu to tray icon and show it.
            trayIcon.ContextMenu = trayMenu;
            trayIcon.Visible     = true;
        }
        public string Recive(Socket s)
        {
            byte[] buffer = new byte[4096];
            s.Receive(buffer);
            string msg = Encoding.UTF8.GetString(buffer);
            try
            {
                
                return msg;
            }
            catch
            {
                return msg;
            }

        }
        public void Send(Socket s, string message)
        {
            byte[] bytes = new byte[256];
            byte[] msg = Encoding.UTF8.GetBytes(message);
            try
            {
                int byteCount = s.Send(msg, SocketFlags.None);
            }
            catch
            {
                s.Connect("127.0.0.1", 5555);
                int byteCount = s.Send(msg, SocketFlags.None);
            }
        }

        protected override void OnLoad(EventArgs e)
        {
            Visible       = true; // Hide form window.
            ShowInTaskbar = true; // Remove from taskbar.
            trayIcon.Visible = false;
            StatusHandler();
            base.OnLoad(e);
        }

        protected void OnOpen(object sender, EventArgs e)
        {
            StatusHandler();
        }
 
        private void OnExit(object sender, EventArgs e)
        {
            trayIcon.Visible = false;
            Application.Exit();
        }



        public void trayIcon_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
            this.ShowInTaskbar = true;
            trayIcon.Visible = false;
            StatusHandler();

        }

        private void MainForm_Resize(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Minimized)
            {
                trayIcon.Visible = true;
                this.ShowInTaskbar = false;
            }
        }
      

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (tabControl1.SelectedIndex)
            {
                case 0:  // Status
                    StatusHandler();
                    break;
                case 1:  // WhiteList
                    WhiteListHandler();
                    break;
                case 2:  // BlackList
                    BlackListHandler();
                    break;

            }
        }

        private void BlackListHandler()
        {
           
        }

        private void WhiteListHandler()
        {
           
        }

        private void StatusHandler()
        {
                Send(this.s, "Status");
                string Status = "";
                string ProcessName = "";
                string EXE_size = "";
                string ProcessNotes = "None";
                try
                {
                    Status = Recive(this.s);
                    Status = Status.Split('\0')[0];
                    if (Status == "Camera is in use")
                    {
                        ProcessName = Recive(this.s);
                        EXE_size = Recive(this.s);
                    }
                    else if (Status == "Camera was not found" || Status == "Camera is not in use")
                    {
                        ProcessName = "None";
                        EXE_size = "None";
                        ProcessNotes = "None";
                    }
                }
                catch
                {
                    Status = "Failed to connect";
                }
                Camera_Status.Text = Status;
                Process_Name.Text = ProcessName;
                Size.Text = EXE_size;
                Notes.Text = ProcessNotes;
                /*switch (Status)
                {
                    case "Camera is in use":
                        Send(this.s, "ProcessName");
                        return;
                    
                }
                */
        }

        private void KillButton_Click(object sender, EventArgs e)
        {
            Send(this.s, "KillThis");
            StatusHandler();
        }
    }
}
