#region ----------   ABOUT   -----------------------------
"""
##################################################################
# Created By: Liel Moalem                                        #
# Date: 20/01/2016                                               #
# Name: CameraStatus                                             #
# Version: 1.0                                                   #
# Windows Tested Versions: Win 7 64-bit                          #
# Python Tested Versions: 2.7 64-bit                             #
# Python Environment  : PyCharm                                  #
##################################################################
"""
#endregion

#region ----Imports----
from CameraStatus import *
import socket
import time
import threading
import pythoncom
#endregion

#region Constants
IP = '127.0.0.1'
PORT = 5555
#endregion

class GUI:
    def __init__(self):
        self.CameraDetails = CameraStatus()
        self.StatusNow = self.CameraDetails.Get_Camera_Status()
        self.GUISOCKET = ""

    def CheckStatus(self):
        while True:
            pythoncom.CoInitialize()
            Check = CameraStatus()
            StatusNow = Check.Get_Camera_Status()
            self.CameraDetails = Check
            self.StatusNow = StatusNow
            pythoncom.CoUninitialize()
            time.sleep(5)

    def Handle_Command(self, GUISOCKET, StatusNow, Check):
            command = GUISOCKET.recv(4096)
            print 'Got a command'
            if command == "Status":

                if StatusNow == '1':

                    GUISOCKET.send("Camera is in use")
                    time.sleep(0.1)
                    GUISOCKET.send(Check.process_name)
                    time.sleep(0.1)
                    GUISOCKET.send(Check.EXE_Size)
                    time.sleep(0.1)

                elif StatusNow == '0':
                    GUISOCKET.send("Camera was not found")

                else:
                    GUISOCKET.send("Camera is not in use")



            if command == "KillThis":
                try:
                    self.CameraDetails.KillProcess(self.CameraDetails.process_id)
                except Exception as detail:
                    print 'run-time error : ', detail
    def threadnum2(self):
        while True:
            self.Handle_Command(self.GUISOCKET, self.StatusNow, self.CameraDetails)

    def run(self):
        Esocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        Esocket.bind((IP, 5555))
        Esocket.listen(1)
        print 'waiting for connections'
        self.GUISOCKET, GUIADRESS = Esocket.accept()
        print 'connected sucssesfully'
        t1 = threading.Thread(target=self.CheckStatus)
        t2 = threading.Thread(target=self.threadnum2)
        t1.start()
        t2.start()
GUI().run()
